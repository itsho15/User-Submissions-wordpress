<?php
    get_header();
?>
<div class="container" id="Content">
    
    <div class="col-sm-12">
        
        <h2 class="submssion-title">All User Submmtions</h2>
        
         <?php echo $__env->make('admin.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         
         <nav class="nav-tab-wrapper">
                 <a class="button type" href="?tab=event" >event</a>
                 <a class="button type" href="?tab=journal">journal</a>
                 <a class="button type" href="?tab=training">training</a>
                 <a class="button type" href="?tab=reports">reports</a>
        </nav>
    </div>
   

    <form action="<?php echo esc_url(url("admin/control/destroy/all")); ?>" method="post" id="formdata" >
        <input type="hidden" id="idsDel" name="items" value="">
        <input type="hidden" name="_token" value="<?php echo e(wpLumen()->csrf()); ?>"/>
    </form>
<table id="table_id" class="display">
    <thead>
        <tr>
            <th scope="col"><input type="checkbox" id="checkAll"/></th>

             <?php if($type == 'event'): ?>

                <th scope="col">organizer</th>
                <th scope="col">start date</th>
                <th scope="col">duration</th>

            <?php elseif($type == 'journal'): ?>

                <th scope="col">author</th>
                <th scope="col">organization</th>
                <th scope="col">issued_date</th>

            <?php elseif($type == 'training'): ?>

                <th scope="col">organizer</th>
                <th scope="col">title</th>
                <th scope="col">provider</th>
                <th scope="col">fee</th>

            <?php elseif($type == 'reports'): ?>

                <th scope="col">organization</th>
                <th scope="col">title</th>
                <th scope="col">author</th>
                <th scope="col">year of release</th>

            <?php endif; ?>
             <th scope="col">Submmtion by</th>
             <th scope="col">Approved or rejected by</th>
             <th scope="col">status</th>
             <th scope="col">Done</th>
             <th scope="col">Edit</th>
             <th scope="col">Approve</th>
             
             <th scope="col">Delete</th>
        </tr>
    </thead>

    <tbody>

        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><input type="checkbox" name="item[]" class="item_checkbox" value="<?php echo e($submission->id); ?>" /></td>

                <?php if($type == 'event'): ?>
                    <td> <?php echo e($submission->event_organizer); ?></td>

                    <td> <?php echo e($submission->event_start_date); ?> </td>
                    <td> <?php echo e($submission->event_duration); ?> </td>

                <?php elseif($type == 'journal'): ?>
                    <td> <?php echo e($submission->journal_author); ?></td>
                    <td> <?php echo e($submission->journal_organization); ?> </td>
                    <td> <?php echo e($submission->journal_issued_date); ?> </td>

                <?php elseif($type == 'training'): ?>

                    <td> <?php echo e($submission->training_organizer); ?></td>
                    <td> <?php echo e($submission->training_title); ?> </td>
                    <td> <?php echo e($submission->training_provider); ?> </td>
                    <td> <?php echo e($submission->training_fee); ?> </td>


                <?php elseif($type == 'reports'): ?>
                    <td> <?php echo e($submission->report_organization); ?> </td>
                    <td> <?php echo e($submission->report_title); ?> </td>
                    <td> <?php echo e($submission->report_author); ?></td>
                    <td> <?php echo e($submission->yearofrelease); ?> </td>

                <?php endif; ?>
                <?php
                    $author_obj = get_user_by('id', $submission->approved_by);
                    $Submmtionby = get_user_by('id', $submission->user_id);
                ?>
                <td> <a href="<?php echo e(get_edit_user_link( $submission->user_id )); ?> "> <?php echo e($Submmtionby->user_nicename); ?> </a></td>
                <?php if($submission->approved_by !=null): ?>
                <td> <a href="<?php echo e(get_edit_user_link( $submission->approved_by )); ?> "> <?php echo e($author_obj->user_nicename); ?> </a></td>
                <?php else: ?>
                    <td> no Data</td>
                <?php endif; ?>
                <td>

                    <?php if($submission->Approval === NULL): ?>

                      <p style="color: #fff;background: orange;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">pending</p>
                     <?php elseif($submission->Approval === 0): ?>
                     <p style="color:#fff;background: red;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">disaproved</p>
                    <?php elseif($submission->Approval === 1): ?>
                    <p style="color:#fff;background: green;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">approved</p>
                    
                    <?php elseif($submission->Approval === 2): ?>
                    <p style="color:#fff;background: red;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">appended</p>

                    <?php endif; ?>
                </td>
                
                <td>

                <?php if($submission->done === 0): ?>

                      <p style="color: #fff;background: orange;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">no answer</p>
                     <?php elseif($submission->Approval === 1): ?>
                     <p style="color:#fff;background: green;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;"> Done on time</p>
              
                    <?php elseif($submission->Approval === 2): ?>
                    <p style="color:#fff;background: red;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;"> Canceled</p> 
                    
                    <?php elseif($submission->Approval === 3): ?>
                    <p style="color:#fff;background: red;padding: 10px; border-radius: 10%;text-align: center;font-weight: bold;">Postponed</p>

                    <?php endif; ?>
                </td>

            <td><button type="button" class="btn btn-primary Edit_data" data-toggle="modal" data-target="edit_<?php echo e($submission->id); ?>">Review</button>
            </td>
            <td><button type="button" class="btn btn-primary approve_data" data-toggle="modal" data-target="approve_<?php echo e($submission->id); ?>">approve/disapproved</button>
            </td>

            <td><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#del_admin<?php echo e($submission->id); ?>">delete</button></td>


            </tr>
            <?php echo $__env->make('front.Submssions.editmodelcontrol', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

<form  id="deletedoc" method="post" action="<?php echo e(esc_url(url("admin/control/destroy/") )); ?>" >
<input type="hidden" name="docId" />
</form>

</table>


    <!-- multi delete -->
<div id="mutlipleDelete" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete</h4>
      </div>
      <div class="modal-body">

        <div class="alert alert-danger">
            <div class="empty_record hidden">
            <h4>Please Check Some Records to Delete Them </h4>
            </div>
            <div class="not_empty_record hidden">
            <h4>are you sure you want to delete submssion with id <span class="record_count"></span> ? </h4>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <div class="empty_record hidden">
        <button type="button" class="btn btn-default" data-dismiss="modal">close</button>
        </div>
        <div class="not_empty_record hidden">
        <button type="button" class="btn btn-default" data-dismiss="modal">no</button>
        <input type="submit"  value="yes"  class="btn btn-danger del_all" onclick="jQuery('#form_data').submit();" />
        </div>
      </div>
    </div>
  </div>
</div>



</div>

<script type="text/javascript">

jQuery(document).ready(function($) {

    $('#table_id').DataTable({
            'dom': 'Blfrtip',
            'buttons'  : [
                { extend: 'print', className: 'button print' },
                { extend: 'csv', className: 'button csv' },
                { extend: 'excel', className: 'button excel' },
                { extend: 'pdf', className: 'button pdf' },
                { extend: 'copy', className: 'button copy' },
                {'text' : '<span class="dashicons dashicons-no"></span> ', 'className' : 'button delete delBtn',},
            ],
            "processing": true,
            "scrollX": true
    });



});

</script>

<?php
    get_footer();
?>

