<div class="wrap">
    <?php echo $__env->yieldContent('heading'); ?>
    <div id="poststuff">

        <?php echo $__env->yieldContent('content'); ?>

        <br class="clear">
        <?php echo $__env->yieldPushContent('js'); ?>
    </div>
    <!-- #poststuff -->
</div> <!-- .wrap -->