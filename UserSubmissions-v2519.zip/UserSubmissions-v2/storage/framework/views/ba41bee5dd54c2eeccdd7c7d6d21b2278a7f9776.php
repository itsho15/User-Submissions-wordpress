<?php get_header(); ?>
<div class="container">

        <div class="uc-seassions-page">
           
            <div class="page-head d-flex justify-content-between">
                 
                <h3 class="submssion-title">
                
                    <?php switch($submission->type):
                            case ('journal'): ?>
                                <?php echo e($submission->journal_title); ?>

                                <?php break; ?>
                            <?php case ('event'): ?>
                                <?php echo e($submission->event_title); ?>

                                <?php break; ?>
                            <?php case ('training'): ?>
                                <?php echo e($submission->training_title); ?>

                                <?php break; ?>
                            <?php case ('reports'): ?>
                                <?php echo e($submission->report_title); ?>

                                <?php break; ?>
                            <?php default: ?>
                                 <?php echo e('no title'); ?>

                                <?php break; ?>
                    <?php endswitch; ?>

                </h3>

                <a onclick="window.print();" class="uc-print"><i class="fas fa-print"></i></a>
            </div>
            
             <?php if($submission->image_cover): ?>
                    <img src="<?php echo e($submission->image_cover); ?>" alt="event image" class="img-responsive" style="max-width:100%">
                    <?php else: ?>
                     <img src="<?php echo e(plugin_dir_url( __DIR__ ) . 'images/default.jpg'); ?>" alt="event image" class="img-responsive" style="max-width:100%;height:auto;">
             <?php endif; ?>

            <p>

                <?php switch($submission->type):
                    case ('journal'): ?>

                        <?php break; ?>
                    <?php case ('event'): ?>
                        <?php if($submission->event_summary_type !=''): ?>
                            <h3 class="uc-properties">Summary of event/campaign type:</h3>
                            <p><?php echo e($submission->event_summary_type); ?></p>
                        <?php endif; ?>

                        <?php break; ?>
                    <?php case ('training'): ?>

                        <?php break; ?>
                    <?php case ('reports'): ?>
                        <?php if($submission->report_abstract !=''): ?>
                            <h3 class="uc-properties">Report Abstract:</h3>
                            <p><?php echo e($submission->report_abstract); ?></p>
                        <?php endif; ?>
                        <?php break; ?>
                    <?php default: ?>
                         <?php echo e('no title'); ?>

                        <?php break; ?>
                <?php endswitch; ?>
            </p>

            <div class="uc-speaker">
                <div class="row">

                    <div class="col-lg-12">
                        <div class="uc-right">

                                <?php switch($submission->type):
                                    case ('journal'): ?>
                                        <?php if($submission->journal_abstract !=''): ?>
                                            <h3 class="uc-properties">Abstract:</h3>
                                            <p><?php echo e($submission->journal_abstract); ?></p>
                                        <?php endif; ?>
                                        <?php break; ?>
                                    <?php case ('event'): ?>
                                            <?php if($submission->event_audience_target !=''): ?>
                                                <h3 class="uc-properties">Target audience:</h3>
                                                <p><?php echo e($submission->event_audience_target); ?></p>
                                            <?php endif; ?>
                                        <?php break; ?>
                                    <?php case ('training'): ?>
                                        <?php if($submission->training_description !=''): ?>
                                             <h3 class="uc-properties">Training description:</h3>
                                             <p><?php echo e($submission->training_description); ?></p>
                                        <?php endif; ?>
                                        <?php break; ?>
                                    <?php case ('reports'): ?>
                                        <?php if($submission->training_description !=''): ?>
                                            <h3 class="uc-properties">Report Abstract:</h3>
                                             <p><?php echo e($submission->report_abstract); ?></p>
                                        <?php endif; ?>
                                        <?php break; ?>
                                    <?php default: ?>
                                         <?php echo e('no title'); ?>

                                        <?php break; ?>
                                <?php endswitch; ?>

                        </div>
                    </div>
                </div>
            </div>

            <h3 class="uc-properties"><?php echo e(ucfirst( $submission->type)); ?> Properties</h3>

            <ul class="uc-table">
                <?php switch($submission->type):
                    case ('journal'): ?>
                       <li><span class="uc-p-left">Date Issued:</span> <span class="uc-p-right"><?php echo e($submission->journal_issued_date); ?></span></li>
                       <li><span class="uc-p-left">Journal author:</span> <span class="uc-p-right"><?php echo e($submission->journal_author); ?></span></li>
                       <li><span class="uc-p-left">Journal authors:</span> <span class="uc-p-right"><?php echo e($submission->journal_authors); ?></span></li>
                       <li><span class="uc-p-left">Journal organization:</span> <span class="uc-p-right"><?php echo e($submission->journal_organization); ?></span></li>
                       <li><span class="uc-p-left">Journal/Conference Name:</span> <span class="uc-p-right"><?php echo e($submission->journal_name); ?></span></li>
                       <li><span class="uc-p-left">URL/website address:</span> <span class="uc-p-right"><a href="<?php echo e($submission->journal_website); ?>" target="_blank"> <?php echo e($submission->journal_website); ?> </a></span></li>
                       <li><span class="uc-p-left">Journal keywords:</span> <span class="uc-p-right"><?php echo e($submission->journal_keywords); ?></span></li>
                        <?php break; ?>
                    <?php case ('event'): ?>
                        <li><span class="uc-p-left">Event start date:</span> <span class="uc-p-right"><?php echo e($submission->event_start_date); ?></span></li>
                       <li><span class="uc-p-left">Event author:</span> <span class="uc-p-right"><?php echo e($submission->event_report_author); ?></span></li>
                       <li><span class="uc-p-left">Event organizer:</span> <span class="uc-p-right"><?php echo e($submission->event_organizer); ?></span></li>
                       <li><span class="uc-p-left">Event duration:</span> <span class="uc-p-right"><?php echo e($submission->event_duration); ?></span></li>
                       <li><span class="uc-p-left">Event sponsor:</span> <span class="uc-p-right"><?php echo e($submission->event_sponsor); ?></span></li>
                       <li><span class="uc-p-left">URL/website address:</span> <span class="uc-p-right"><a href="<?php echo e($submission->event_website); ?>" target="_blank"> <?php echo e($submission->event_website); ?> </a></span></li>
                       <li><span class="uc-p-left">Event keywords:</span> <span class="uc-p-right"><?php echo e($submission->event_keywords); ?></span></li>
                        <?php break; ?>
                    <?php case ('training'): ?>
                       <li><span class="uc-p-left">Date Issued:</span> <span class="uc-p-right"><?php echo e($submission->training_issued_date); ?></span></li>
                       <li><span class="uc-p-left">Training organizer:</span> <span class="uc-p-right"><?php echo e($submission->training_organizer); ?></span></li>
                        <li><span class="uc-p-left">Training provider:</span> <span class="uc-p-right"><?php echo e($submission->training_provider); ?></span></li>
                       <li><span class="uc-p-left">Registration fee:</span> <span class="uc-p-right"><?php echo e($submission->training_fee); ?></span></li>
                       <li><span class="uc-p-left">Attendance type:</span> <span class="uc-p-right"><?php echo e($submission->training_type); ?></span></li>
                       <li><span class="uc-p-left">Duration:</span> <span class="uc-p-right"><?php echo e($submission->training_duration); ?></span></li>
                       <li><span class="uc-p-left">URL/website address:</span> <span class="uc-p-right"><a href="<?php echo e($submission->training_website); ?>" target="_blank"> <?php echo e($submission->training_website); ?> </a></span></li>
                       <li><span class="uc-p-left">keywords:</span> <span class="uc-p-right"><?php echo e($submission->training_keywords); ?></span></li>
                        <?php break; ?>
                    <?php case ('reports'): ?>
                       <li><span class="uc-p-left">Report organization:</span> <span class="uc-p-right"><?php echo e($submission->report_organization); ?></span></li>
                        <li><span class="uc-p-left">Year of release:</span> <span class="uc-p-right"><?php echo e($submission->yearofrelease); ?></span></li>
                       <li><span class="uc-p-left">State plan:</span> <span class="uc-p-right"><?php echo e($submission->stateplan); ?></span></li>
                       <li><span class="uc-p-left">Report authors:</span> <span class="uc-p-right"><?php echo e($submission->report_authors); ?></span></li>
                       <li><span class="uc-p-left">Year term:</span> <span class="uc-p-right"><?php echo e($submission->yearterm); ?></span></li>
                       <li><span class="uc-p-left">Report keywords:</span> <span class="uc-p-right"><?php echo e($submission->report_keywords); ?></span></li>
                        <?php break; ?>
                    <?php default: ?>
                         <?php echo e('no title'); ?>

                        <?php break; ?>
                <?php endswitch; ?>

                <li><span class="uc-p-left">Attachment</span>
                    <span class="uc-p-right">

                    <?php $__currentLoopData = $submission->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                                 $filterdName = pathinfo($doc->name);
                    ?>
                    <a class="uc-pdf" href="<?php echo e($doc->name); ?>" target="_blank"><?php echo e($filterdName['filename'].'.'.$filterdName['extension']); ?></a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </span>
                </li>
            </ul>
        </div>
</div>
<?php get_footer(); ?>