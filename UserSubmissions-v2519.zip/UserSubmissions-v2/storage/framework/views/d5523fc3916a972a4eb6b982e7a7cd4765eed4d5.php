<?php
get_header();
?>
<div class="submission-table">
<h3>My Submissions</h3>

<?php echo $__env->make('admin.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<a href="<?php echo e(url('upload/yourresearch')); ?>">Create New Submission</a>

	<input type="text" id="myInput" onkeyup="filterFunc()" placeholder="filter by type" title="Type in a type">

		<table id="myTable">

		  <tr class="header">
		    <th>id</th>
		    <th>type</th>
		    <th>files</th>
		    <th>status</th>
		    <th>actions</th>
		  </tr>


<?php $__currentLoopData = $UserSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php
	$UserDocuments = \App\Models\Documents::where('submission_id', $submission->id)->get();

	$documents = "";

	$actions = '<button type="button" class="btn btn-primary Edit_sub" data-toggle="modal" data-target="edit_' . $submission->id . '"><i class="fa fa-edit"></i>Edit</button>
	<button type="button" class="btn btn-danger del_sub" data-toggle="modal" data-target="del_' . $submission->id . '"><i class="fa fa-trash"></i>Delete</button>
			';
	?>

	<?php $__currentLoopData = $UserDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php
		$filterdName = pathinfo($doc->name); //file name without extension

		$documents .= "<li> <a href='{$doc->name}'> {$filterdName['filename']}.{$filterdName['extension']}</a> </li>";
		?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php if($submission->Approval === NULL): ?>
		<?php $checkApproval = "Waiting Approvel From Admin"; ?>
	<?php elseif($submission->Approval === 0): ?>
		<?php $checkApproval = "rejected From admin , reason: $submission->reason_approve "; ?>
	<?php elseif($submission->Approval === 1): ?>
		<?php $checkApproval = "Submission Approved From Admin"; ?>
	<?php endif; ?>


    <?php
	echo "<tr>";
	echo "<td>{$submission->id}</td>";
	echo "<td>{$submission->type}</td>";
	echo "<td> Submissions files <ul> {$documents} </ul> </td>";
	echo "<td>{$checkApproval}</td>";
	echo "<td>{$actions}</td>";
	echo "</tr>";
	?>

	<?php echo $__env->make('front.Submssions.editsub', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 

</table>
  <div class="tablenav bottom alignleft">
    <?php echo $UserSubmissions->links('pagination.bootstrap-4'); ?>

</div>

<form  id="deletedoc" method="post" action="<?php echo e(esc_url(url("document/destroy/") )); ?>" >
<input type="hidden" name="docId" />
</form>

</div>


<?php get_footer();?>