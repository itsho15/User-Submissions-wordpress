<?php if($helper->session()->has('success')): ?>

<div class="alert alert-success">
	<p class="text-center"> <i class="fa fa-check-square fa-lg" aria-hidden="true"></i> <?php echo e($helper->session()->get('success')); ?> </p>
</div>

<?php endif; ?>

<?php if(isset($_GET['success'])): ?>

	<?php
	$class = 'updated notice-info';
	$message = __( $_GET['success']);

	printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
	?>
<?php endif; ?>

<?php if(isset($_GET['errors']) ): ?>
	<div class="alert alert-danger ">

	<?php $__currentLoopData = $_GET['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<p class="text-center"><?php echo e($key); ?></p>

		<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<span>
			<?php echo e(str_replace('validation.', '', $validate)); ?>

		    </span>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

<?php endif; ?>


<?php if($helper->session()->has('error') ): ?>

<div class="alert alert-danger">
	<p class="text-center"> <i class="fa fa-exclamation-triangle fa-lg" aria-hidden="true"></i> <?php echo e($helper->session()->get('error')); ?> </p>
</div>

<?php endif; ?>

<?php if($helper->session()->has('info') ): ?>

<div class="alert alert-info">
	<p class="text-center">
		<i class="fa fa-exclamation fa-lg" aria-hidden="true"></i>
	<?php echo e($helper->session()->get('info')); ?>

    </p>
</div>

<?php endif; ?>

<?php if($helper->session()->get('errors') >0 ): ?>
	<div class="alert alert-danger ">

	<?php $__currentLoopData = $helper->session()->get('errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<p class="text-center"><?php echo e($key); ?></p>

		<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<span>
			<?php echo e(str_replace('validation.', '', $validate)); ?>

		    </span>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

<?php endif; ?>
