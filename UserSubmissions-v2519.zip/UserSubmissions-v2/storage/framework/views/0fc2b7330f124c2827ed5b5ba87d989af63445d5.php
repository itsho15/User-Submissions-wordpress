<div class="container">
    <?php if(is_page()): ?>
    <h2 class="submssion-title"><?php echo e(get_the_title()); ?></h2>
    <?php endif; ?>
    <div class="row">
        <?php
            $i =0;


        ?>
        <?php $__currentLoopData = $submssions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submssion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $image = "<a href=".url('submission/'.$submssion->id)."><img class='img-fluid' src='https://godigital.motc.gov.qa/media/com_eventbooking/images/thumbs/Nov26-3.jpg' alt='' /></a>";
            ?>
         <div class="col-lg-4">

            <?php if($type == 'training'): ?>

                <div class="uc-seassions">
                    <h3><a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><?php echo e($submssion->training_title); ?></a></h3>
                    <div class="uc-thumb">
                       <?php if($submssion->image_cover): ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e($submssion->image_cover); ?>" alt='' /></a>
                            <?php else: ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e(plugin_dir_url( __DIR__ ) . 'images/default.jpg'); ?>" alt='' /></a>
                             
                            <?php endif; ?>
                        <span class="address"><?php echo e($submssion->training_organizer); ?></span>
                    </div>
                    <div class="uc-meta">
                        <span class="date"><?php echo e($submssion->training_issued_date); ?></span>
                        <!--<span class="time">15:30 -17:30</span>-->
                    </div>
                    <div class="uc-buttons">
                            <!--<a class="reg" href="#">Register</a>-->
                        <a class="details" href="<?php echo e(url('submission/'.$submssion->id)); ?>">Details</a>
                    </div>
                </div>

            <?php elseif($type == 'event'): ?>

                <div class="uc-seassions">
                    <h3><a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><?php echo e($submssion->event_title); ?></a></h3>
                    <div class="uc-thumb">
                        
                        <?php if($submssion->image_cover): ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e($submssion->image_cover); ?>" alt='' /></a>
                            <?php else: ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e(plugin_dir_url( __DIR__ ) . 'images/default.jpg'); ?>" alt='' /></a>
                             
                            <?php endif; ?>

                        <span class="address"><?php echo e($submssion->event_organizer); ?></span>
                    </div>
                    <div class="uc-meta">
                        <span class="date"><?php echo e($submssion->event_start_date); ?></span>
                        <!--<span class="time">15:30 -17:30</span>-->
                    </div>
                    <div class="uc-buttons">
                            <!--<a class="reg" href="#">Register</a>-->
                            <a class="details" href="<?php echo e(url('submission/'.$submssion->id)); ?>">Details</a>
                   </div>
                </div>

            <?php elseif($type == 'journal'): ?>

                <div class="uc-seassions">
                    <h3><a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><?php echo e($submssion->journal_title); ?></a></h3>
                    <div class="uc-thumb">
                       <?php if($submssion->image_cover): ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e($submssion->image_cover); ?>" alt='' /></a>
                            <?php else: ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e(plugin_dir_url( __DIR__ ) . 'images/default.jpg'); ?>" alt='' /></a>
                             
                            <?php endif; ?>
                        <span class="address"><?php echo e($submssion->journal_organization); ?></span>
                    </div>
                    <div class="uc-meta">
                        <span class="date"><?php echo e($submssion->journal_issued_date); ?></span>
                        <!--<span class="time">15:30 -17:30</span>-->
                    </div>
                    <div class="uc-buttons">
                            <!--<a class="reg" href="#">Register</a>-->
                            <a class="details" href="<?php echo e(url('submission/'.$submssion->id)); ?>">Details</a>
                    </div>
                </div>
            <?php elseif($type == 'reports'): ?>

                    <div class="uc-seassions">
                        <h3><a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><?php echo e($submssion->report_title); ?></a></h3>
                        <div class="uc-thumb">
                          
                            <?php if($submssion->image_cover): ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e($submssion->image_cover); ?>" alt='' /></a>
                            <?php else: ?>
                             <a href="<?php echo e(url('submission/'.$submssion->id)); ?>"><img class='img-fluid' src="<?php echo e(plugin_dir_url( __DIR__ ) . 'images/default.jpg'); ?>" alt='' /></a>
                             
                            <?php endif; ?>
                            
                            <span class="address"><?php echo e($submssion->report_organization); ?></span>
                        </div>
                        <div class="uc-meta">
                            <span class="date"><?php echo e($submssion->yearterm); ?></span>
                           <!--<span class="time">15:30 -17:30</span>-->
                        </div>
                        <div class="uc-buttons">
                            <!--<a class="reg" href="#">Register</a>-->
                            <a class="details" href="<?php echo e(url('submission/'.$submssion->id)); ?>">Details</a>
                        </div>
                    </div>
            <?php endif; ?>

        </div>
        <?php
            $i++;
            if ($i % 3 == 0) {echo '</div><div class="row">';}
        ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>

<div class="tablenav bottom alignleft">
    <?php echo $submssions->links('pagination.bootstrap-4'); ?>

</div>

