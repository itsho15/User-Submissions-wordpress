<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class WpCommentMeta extends Model {

    //ToDo: Implement WpComment Meta Model
}