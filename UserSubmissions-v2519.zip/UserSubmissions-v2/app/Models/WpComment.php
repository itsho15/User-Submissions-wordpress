<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class WpComment extends Model {
	protected $table = 'comments';
	protected $primaryKey = 'comment_ID';
	public $timestamps = false;

	//ToDo: Implement WpComment Model
}