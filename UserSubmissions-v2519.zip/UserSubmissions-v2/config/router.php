<?php
return [
	'loading' => 'eager',
];
