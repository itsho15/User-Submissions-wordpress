
<h2><?php esc_html_e( 'Spinners', 'wp_admin_style' ); ?></h2>
<p><?php esc_html_e( 'The Spinner element is new since WordPress version 4.2.', 'wp_admin_style' );?> <?php printf( __( 'See <a href="%s" target="_blank">this post on make.w.org</a> for further details.', 'wp_admin_style' ), esc_url( 'https://make.wordpress.org/core/2015/04/23/spinners-and-dismissible-admin-notices-in-4-2/' ) ); ?></p>

<div class="spinner is-active" style="float:none;width:auto;height:auto;padding:10px 0 10px 50px;background-position:20px 0;"></div>