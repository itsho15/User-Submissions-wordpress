<div class="postbox">
    <div class="handlediv" title="Click to toggle"><br></div>
    <!-- Toggle -->
    <h2 class="hndle">
            <span>
                Test
            </span>
    </h2>
    <div class="inside">
        Test
    </div>
    <!-- .inside -->
</div>
<!-- .postbox -->