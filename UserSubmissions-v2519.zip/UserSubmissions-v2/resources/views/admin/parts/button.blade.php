<a href="#" class="button button-primary button-hero">Hero Button</a>
<input type="button" class="button button-primary button" value="Hero Button" />

<a href="#" class="button button-secondary button-hero">Hero Button</a>
<input type="button" class="button button-secondary button" value="Hero Button" />





