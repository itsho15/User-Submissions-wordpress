<table style="width: 80%;text-align: center;border: 0 none">
    <tbody>
    <tr>
        <td style="border: 0 none">prior WordPress 4.2</td>
        <td style="border: 0 none">since WordPress 4.2</td>
    </tr>
    <tr>
        <td style="background: #0074a2;color: #fff;border: 2px solid #fff;padding: 2em
0">#0074a2</td>
        <td style="background: #0073aa;color: #fff;border: 2px solid #fff;padding: 2em
0">#0073aa</td>
    </tr>
    <tr>
        <td style="background: #2ea2cc;color: #fff;border: 2px solid #fff;padding: 2em
0">#2ea2cc</td>
        <td style="background: #00a0d2;color: #fff;border: 2px solid #fff;padding: 2em
0">#00a0d2</td>
    </tr>
    <tr>
        <td style="background: #45bbe6;color: #fff;border: 2px solid #fff;padding: 2em
0">#45bbe6</td>
        <td style="background: #00b9eb;color: #fff;border: 2px solid #fff;padding: 2em
0">#00b9eb</td>
    </tr>
    </tbody>
</table>