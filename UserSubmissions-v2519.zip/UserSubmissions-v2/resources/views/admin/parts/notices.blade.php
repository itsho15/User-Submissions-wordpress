
<div class="notice notice-success">
    <p>This is a success notice.</p>
</div>

<div class="notice notice-error">
    <p>This is an error notice.</p>
</div>

<div class="notice notice-warning">
    <p>This is a warning notice.</p>
</div>

<div class="notice notice-info is-dismissible">
    <p>This is an info notice.</p>
</div>

