<div class="card">
    <h2>Card Title</h2>
    <p>Card Content</p>
</div>
