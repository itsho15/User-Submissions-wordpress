@extends('admin.layouts.default')

@section('heading')

@endsection

@section('content')
    @include('admin.parts.tabs')
@endsection