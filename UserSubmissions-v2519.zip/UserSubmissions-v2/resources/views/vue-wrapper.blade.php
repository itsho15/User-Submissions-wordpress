<div id="vue_wrapper">
    @yield('content')
</div>
