<?php
return [
	'name'      => 'LumenPlugin',
	'author'    => 'SomeDev',
	'trademark' => '© Copyright 2017 - All Rights Reserved.',
	'test'      => 'هشام',
];